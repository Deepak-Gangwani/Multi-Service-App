from django.contrib import admin
from django.urls import path
from mychatapp import views

urlpatterns = [
    path("", views.mychatapp),
    path("room/", views.room),
]
