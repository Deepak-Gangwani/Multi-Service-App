
from django.contrib import admin
from django.urls import path
from photoapp import views


urlpatterns = [
    path("", views.photoapp, name="photoapp"),
    path("viewPhoto/<str:pk>", views.viewPhoto, name="viewphoto"),
    path("addPhoto/", views.addPhoto, name="addphoto"),
    path("deletePhoto/<str:pk>",views.deletePhoto,name="deletephoto")
   
    
]
