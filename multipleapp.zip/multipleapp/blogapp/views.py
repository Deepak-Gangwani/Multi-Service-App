from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
def blogapp(request):
    return HttpResponse("<h1>This is blogapp page</h1>")
